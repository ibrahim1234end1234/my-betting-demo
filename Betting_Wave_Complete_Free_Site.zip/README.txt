BETTING WAVE — COMPLETE FREE STATIC WEBSITE

FILES
- index.html: home page
- matches.html: match insights
- news.html: sports news
- stats.html: statistics
- responsible.html: responsible gaming page
- privacy.html: privacy policy template
- terms.html: terms template
- contact.html: contact page
- logo.svg: site logo

META PIXEL
1. Create your Meta Pixel/Dataset in Events Manager.
2. Choose “Set up Meta pixel” → “Add Meta pixel code to website yourself”.
3. Copy Meta's official base code.
4. Open each HTML page and paste the code inside <head>, at the marked comment.
5. Publish the site and use Meta Test Events to verify it.

IMPORTANT
This site is intentionally informational. It does not process betting transactions or help bypass Meta advertising rules. Replace placeholder contact details and policy text with information that accurately reflects your actual business and data practices.
